// src/pages/thankyou.tsx
export default function ThankYou() {
  return (
    <main>
      <h2>Terima kasih sudah mengisi survei!</h2>
    </main>
  );
}
